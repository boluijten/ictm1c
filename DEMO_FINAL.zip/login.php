<html>

<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<style>
</style>

<body>
  <!-- Top Navigatie Balk -->
  <div class="navbar">

  <href="index.html"><img style="width:auto; height:80px;" src="logo.png">
  <a href="#contact"><img style="width:auto; height:30px;" src="winkelmandje.png"></a>
  <a href="#news">Inloggen</a>

    <!-- De zoekbalk-->
  <div class="search-container">
  <form action="/action_page.php">
    <input type="text" placeholder="Search.." name="search">
    <button type="submit"><i style="height:25px; width:auto;"class="fa fa-search"></i></button>
  </form>
  </div>
</div>

        <br>
        <br>
        <br>
        <br>
<form>
    <h2><b><pre>Inloggen</pre></b></h2>
            <table>
                <tr>
                    <td align = "left"><pre>    Gebruikersnaam: </pre></td>
                    <td align = "left"><input type = "text" name = "gebruikersnaam" /></td>
                </tr>
                <tr>
                    <td align = "left"><pre>    Wachtwoord: </pre></td>
                    <td align = "left"><input type = "text" name = "wachtwoord" /></td>
                </tr>
                <tr>
                <td align = "right"><pre>    <input type = "submit" value = "Inloggen en verder gaan"></pre></td>
                </tr>
            </table>
        </form>
      <p><b><pre>    Of:</pre></b></p>
    <h2><b><pre>  Gegevens invoeren: </pre></b></h2>
      <form>
        <table>
            <tr>
                <td align = "left"><pre>    Voornaam: </pre></td>
                <td align = "left"><input type = "text" name = "voornaam" /></td>
                <td align = "left"><pre>    Achternaam: </pre></td>
                <td align = "left"><input type = "text" name = "achternaam" /></td>
            </tr>
            <tr>
                <td align = "left"><pre>    Emailadres: </pre></td>
                <td align = "left"><input type = "text" name = "emailadres" /></td>
                <td align = "left"><pre>    Telefoonnummer: </pre></td>
                <td align = "left"><input type = "text" name = "telefoonnummer" /></td>
            </tr>
            <tr>
                <td align = "left"><pre>    Woonplaats: </pre></td>
            <td align = "left"><input type = "text" name = "woonplaats"/></td>
            <td align = "left"><pre>    Straatnaam: </pre></td>
            <td align = "left"><input type = "text" name = "straatnaam"/></td>
            </tr>
            <tr>
            <td align = "left"><pre>    Huisnummer: </pre></td>
            <td align = "left"><input type = "text" name = "huisnummer"/></td>
            <td align = "left"><pre>    postcode: </pre></td>
            <td align = "left"><input type = "text" name = "postcode"/></td>
        </tr>
            <tr>
                <td align = "right"><pre>    <input type = "submit" value = "Verder gaan"></pre></td>
            </tr>
            <td align = "left"><pre>    <button type = "button">Terug</button></pre></td>
    </table>
</form>



</body>

</html>
