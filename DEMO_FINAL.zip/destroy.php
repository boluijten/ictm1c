<?php
session_start();
//$_SESSION['cart'] = array(1 => 3, 4 => 5, 7 => 7, 3 => 10, 30 => 1);
session_destroy();
?>